# Yayın ajanı (7/24 Twitch)

Yankı'yı kendi kendine oynatır (`bot.js` akıllı oyuncu), ekrana oyun adı ve itch.io bağlantısını yazar, Twitch'e canlı yayınlar. Ses yoktur (sessiz ses kanalı eklenir). 720x1280 dikey, 30 kare, 2500 kbps.

## VPS'e kurulum (root)
```
cd ~ && git clone https://github.com/Aegean-35/dodge-yourself yanki && cd yanki/yayin && bash kur.sh
```
`kur.sh` Twitch yayın anahtarını sorar ve `/etc/yanki-yayin.env` içine yazar. Anahtar: Twitch > Yaratıcı Paneli > Ayarlar > Yayın > Birincil Yayın Anahtarı.

## Komutlar
```
systemctl start yanki-yayin      # yayın aç
systemctl stop yanki-yayin       # kapat
journalctl -u yanki-yayin -f     # her 10 sn: kare sayısı, durum, rekor
node yayin.js --out d.mp4 --seconds 20   # Twitch'siz deneme videosu
```
Servis çökerse 15 sn sonra kendini yeniden başlatır.

## Seçenekler (`yayin.js`)
`--kbps 2500`, `--fps 30`, `--link aegean35.itch.io/dodge-yourself-demo` (alt yazıdaki bağlantı), `--game ../src/game.html`.
Oyun Play'e çıkınca `--link` olarak Play adresi verilir (servis dosyasında ExecStart satırına eklenir).

## Notlar
- `src/game.html` içinde `[hidden]{display:none!important}` kuralı yok (www kopyasında var); yayın kopyası bunu kendi ekler.
- Tek VPS'te aynı anda 3 oyunu yayınlamak için her oyuna ayrı Twitch hesabı ve ayrı servis gerekir; CPU'ya göre 2 yayın sınır olabilir.
