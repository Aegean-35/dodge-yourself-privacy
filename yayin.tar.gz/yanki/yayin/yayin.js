/* Yayın ajanı: Yankı'yı kendi kendine oynatır ve Twitch'e (ya da dosyaya) canlı yayınlar.
   Kullanım:
     Deneme (dosyaya 20 sn):  node yayin.js --out deneme.mp4 --seconds 20
     Canlı:                   TWITCH_KEY=xxxx node yayin.js
   Seçenekler: --url rtmp://live.twitch.tv/app/   --fps 30   --kbps 2500   --game ../src/game.html
   Ses yok (sessiz ses kanalı eklenir; Twitch sessiz yayını kabul eder). */
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const GAME = path.resolve(__dirname, opt('game', '../src/game.html'));
const OUT = opt('out', '');
const SECONDS = parseFloat(opt('seconds', '0'));
const FPS = parseInt(opt('fps', '30'), 10);
const KBPS = parseInt(opt('kbps', '2500'), 10);
const KEY = process.env.TWITCH_KEY || '';
const URL = opt('url', 'rtmp://live.twitch.tv/app/');
const LINK = opt('link', 'aegean35.itch.io/dodge-yourself-demo');
const W = 720, H = 1280;
const DRIVER = `(function(){var overAt=0,games=0;noAds=true;
setInterval(function(){try{
  var go=document.getElementById('goendless'),again=document.getElementById('again');
  if(state==='menu'&&!elStart.hidden&&go&&!go.hidden){go.click();return}
  if(!elOver.hidden&&state!=='play'){
    if(!overAt)overAt=Date.now();
    if(Date.now()-overAt>3500){overAt=0;games++;again.click()}
  }else overAt=0;
  var e=document.getElementById('yy-best');
  e.textContent='24/7 auto-play · stream best '+(window.__best||0)+' · game #'+(games+1);
}catch(e){}},400);
})();
`;

if (!OUT && !KEY) { console.log('TWITCH_KEY yok. Deneme için: node yayin.js --out deneme.mp4 --seconds 20'); process.exit(1); }

/* Oyunun yayın kopyası: akıllı oyuncu + menü sürücüsü + ekran yazıları */
function buildPage() {
  let html = fs.readFileSync(GAME, 'utf8');
  const bot = fs.readFileSync(path.join(__dirname, 'bot.js'), 'utf8');
  if (!html.includes('/*HOOK*/')) throw new Error('oyunda /*HOOK*/ işareti yok');
  html = html.replace('/*HOOK*/', '/*HOOK*/' + bot);
  const extra = `
<style>
[hidden]{display:none!important}
#yy-top,#yy-bot,#yy-best{position:fixed;left:0;right:0;z-index:98;text-align:center;pointer-events:none;color:#fff;text-shadow:0 2px 0 rgba(0,0,0,.5);font:600 15px/1.2 var(--body,system-ui)}
#yy-top{top:10px;font:700 17px/1.2 var(--display,system-ui);letter-spacing:.04em}
#yy-best{top:34px;font-size:13px;opacity:.85}
#yy-bot{bottom:8px;background:rgba(0,0,0,.45);padding:8px 0;font-size:16px}
#yy-bot b{color:#ffd54a}
</style>
<div id="yy-top">YANKI · dodge your own echo</div>
<div id="yy-best">24/7 auto-play · stream best 0</div>
<div id="yy-bot">Play free: <b>${LINK}</b></div>
`;
  html = html.includes('</body>') ? html.replace('</body>', extra + '</body>') : html + extra;
  /* Menü sürücüsü oyun değişkenlerine (state, elStart...) erişmek için oyunun kendi kapsamına eklenir */
  const anchor = "$('goendless').addEventListener('click',function(){mode='endless';newGame()});";
  if (!html.includes(anchor)) throw new Error('menü sürücüsü için çapa satırı bulunamadı (goendless)');
  html = html.replace(anchor, anchor + DRIVER);
  const out = path.join(__dirname, 'oyun-yayin.html');
  fs.writeFileSync(out, html);
  return out;
}

(async () => {
  const page_file = buildPage();
  const dst = OUT ? path.resolve(OUT) : URL.replace(/\/?$/, '/') + KEY;
  const ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'warning', '-y',
    '-use_wallclock_as_timestamps', '1', '-f', 'image2pipe', '-c:v', 'mjpeg', '-i', 'pipe:0',
    '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
    '-vf', `fps=${FPS},format=yuv420p`, '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency',
    '-b:v', KBPS + 'k', '-maxrate', KBPS + 'k', '-bufsize', (KBPS * 2) + 'k', '-g', String(FPS * 2), '-keyint_min', String(FPS * 2),
    '-c:a', 'aac', '-b:a', '64k', '-shortest', '-f', OUT ? 'mp4' : 'flv', dst], { stdio: ['pipe', 'inherit', 'inherit'] });
  let dead = false;
  ff.on('exit', (c) => { dead = true; console.log('ffmpeg kapandı: ' + c); });

  const exe = process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {};
  const browser = await chromium.launch({ ...exe, args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1, locale: 'en-US' });
  const page = await ctx.newPage();
  await page.goto('file://' + page_file);
  await page.waitForTimeout(500);
  await page.evaluate(() => { const m = document.getElementById('mute'); if (m) m.style.visibility = 'hidden'; });
  const cdp = await ctx.newCDPSession(page);
  let frames = 0, dropped = 0;
  cdp.on('Page.screencastFrame', (f) => {
    cdp.send('Page.screencastFrameAck', { sessionId: f.sessionId }).catch(() => {});
    if (dead) return;
    if (ff.stdin.writableLength > 3e6) { dropped++; return; }
    ff.stdin.write(Buffer.from(f.data, 'base64'));
    frames++;
  });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 80, maxWidth: W, maxHeight: H, everyNthFrame: 2 });
  const t0 = Date.now();
  while (!dead && (!SECONDS || Date.now() - t0 < SECONDS * 1000)) {
    await page.waitForTimeout(10000);
    const s = await page.evaluate(() => ({ st: window.__snap ? window.__snap() : null, best: window.__best })).catch(() => null);
    console.log(`${Math.round((Date.now() - t0) / 1000)} sn | ${frames} kare, ${dropped} atlandı | ${JSON.stringify(s)}`);
  }
  await cdp.send('Page.stopScreencast').catch(() => {});
  ff.stdin.end();
  await new Promise((r) => ff.on('exit', r));
  await browser.close();
  console.log('bitti');
})().catch((e) => { console.log('Yayın hatası: ' + e.message); process.exit(1); });
