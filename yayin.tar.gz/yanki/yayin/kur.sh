#!/usr/bin/env bash
# Yankı yayın ajanı kurulumu (Ubuntu/Debian VPS, root ile çalıştır).
# Kullanım: bash kur.sh
set -e
cd "$(dirname "$0")"
echo "== Paketler"
apt-get update -qq && apt-get install -y -qq ffmpeg git curl libnss3 libnspr4 >/dev/null
if ! command -v node >/dev/null || [ "$(node -v | cut -c2-3)" -lt 18 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null && apt-get install -y -qq nodejs >/dev/null
fi
echo "== Playwright + Chromium"
npm install --no-save playwright@1.56.0 >/dev/null
# Playwright çok yeni Ubuntu sürümlerini tanımaz; 24.04 gibi davran, bağımlılıklar apt ile geldi
export PLAYWRIGHT_HOST_PLATFORM_OVERRIDE=ubuntu24.04-x64
npx playwright install chromium >/dev/null
CHROME=$(ls /root/.cache/ms-playwright/chromium-*/chrome-linux*/chrome | head -1)
MISSING=$(ldd "$CHROME" | grep "not found" || true); [ -n "$MISSING" ] && { echo "Eksik kütüphane:"; echo "$MISSING"; exit 1; }
echo "== Yayın anahtarı"
if [ ! -f /etc/yanki-yayin.env ]; then
  read -r -p "Twitch yayın anahtarı (live_... ile başlar): " KEY
  printf 'TWITCH_KEY=%s\nPLAYWRIGHT_HOST_PLATFORM_OVERRIDE=ubuntu24.04-x64\nCHROME_PATH=%s\n' "$KEY" "$CHROME" > /etc/yanki-yayin.env; chmod 600 /etc/yanki-yayin.env
fi
echo "== Servis"
sed "s|__DIR__|$(pwd)|g" yanki-yayin.service > /etc/systemd/system/yanki-yayin.service
systemctl daemon-reload && systemctl enable yanki-yayin >/dev/null
echo
echo "Hazır. Komutlar:"
echo "  systemctl start yanki-yayin     # yayını aç"
echo "  systemctl stop yanki-yayin      # kapat"
echo "  journalctl -u yanki-yayin -f    # ne oluyor"
echo "  node yayin.js --out d.mp4 --seconds 20   # Twitch'siz deneme"
