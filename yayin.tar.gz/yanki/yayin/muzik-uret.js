/* Müzik üretici: yayın için telifsiz parçalar üretir (tamamen sentez, örnek/sample yok).
   Kullanım: node muzik-uret.js [--n 4] [--seconds 150] [--out muzik] [--style lofi|hareketli|spa|karisik]
   lofi: sakin lo-fi (70-80 bpm) · hareketli: oyun temposu (108-124 bpm) · spa: davulsuz, pentatonik, çok yavaş · karisik: sırayla üçü
   Çıktı: muzik/parca-01.wav ... (yayin.js bu klasörü bulursa döngüyle çalar) */
const fs = require('fs');
const path = require('path');
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const N = parseInt(opt('n', '4'), 10), SEC = parseFloat(opt('seconds', '150')), OUT = path.resolve(__dirname, opt('out', 'muzik'));
const STYLE = opt('style', 'karisik');
const SR = 44100;

function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const midi = (m) => 440 * Math.pow(2, (m - 69) / 12);
/* akor dizileri (yarım ton, köke göre) ve kökler: hepsi minör/dorian, sakin */
const PROGS = [[[0, 3, 7, 10], [-4, 0, 3, 7], [-7, -3, 0, 3], [-5, -1, 2, 5]], [[0, 3, 7, 10], [5, 8, 12, 15], [-2, 2, 5, 8], [-4, 0, 3, 7]], [[0, 4, 7, 11], [-3, 0, 4, 7], [-7, -3, 0, 4], [-5, -1, 2, 7]]];

function render(seed, style) {
  const r = rng(seed);
  const bpm = style === 'hareketli' ? 108 + Math.floor(r() * 16) : style === 'spa' ? 46 + Math.floor(r() * 8) : 68 + Math.floor(r() * 14);
  const beat = 60 / bpm, bar = beat * 4, drums = style !== 'spa', busy = style === 'hareketli';
  const root = 57 + Math.floor(r() * 6), prog = PROGS[Math.floor(r() * PROGS.length)];
  const total = Math.floor(SEC * SR), L = new Float32Array(total), R = new Float32Array(total);
  const scale = style === 'spa' ? [0, 3, 5, 7, 10, 12, 15, 17, 19] : [0, 2, 3, 5, 7, 10, 12, 14, 15];
  let lpL = 0, lpR = 0;
  /* notalar: {t, dur, f, amp, type} */
  const notes = [];
  const bars = Math.ceil(SEC / bar);
  for (let b = 0; b < bars; b++) {
    const ch = prog[Math.floor(b / 2) % prog.length];
    ch.forEach((iv, k) => notes.push({ t: b * bar, dur: bar * 1.05, f: midi(root + iv + (k === 0 ? 0 : 0)), amp: .07, type: 'pad' }));
    notes.push({ t: b * bar, dur: bar * .9, f: midi(root + ch[0] - 12), amp: .16, type: 'bass' });
    if (b % 4 === 3) notes.push({ t: b * bar + beat * 2, dur: beat * 1.8, f: midi(root + ch[0] - 12 + 7), amp: .12, type: 'bass' });
    /* arpej / melodi: 8'lik ritimde, rastgele boşluklu */
    for (let s = 0; s < (busy ? 16 : 8); s++) {
      if (r() < (style === 'spa' ? .7 : busy ? .25 : .45)) continue;
      const deg = scale[Math.floor(r() * scale.length)];
      notes.push({ t: b * bar + s * beat / (busy ? 4 : 2) + (r() * .02), dur: beat * (style === 'spa' ? 2.5 + r() * 2 : .6 + r() * .9), f: midi(root + 12 + deg + (busy && r() < .3 ? 12 : 0)), amp: style === 'spa' ? .06 + r() * .03 : .09 + r() * .05, type: style === 'spa' ? 'bell' : 'pluck' });
    }
    /* hafif hi-hat ve yumuşak kick */
    if (drums) {
      for (let s = 0; s < 8; s++) if (s % 2 === 1 || busy || r() < .3) notes.push({ t: b * bar + s * beat / 2, dur: .05, f: 0, amp: (busy ? .035 : .025) + r() * .01, type: 'hat' });
      if (busy) { for (let s = 0; s < 4; s++) notes.push({ t: b * bar + s * beat, dur: .25, f: 58, amp: .24, type: 'kick' }); notes.push({ t: b * bar + beat, dur: .12, f: 0, amp: .07, type: 'snare' }); notes.push({ t: b * bar + beat * 3, dur: .12, f: 0, amp: .07, type: 'snare' }); }
      else { notes.push({ t: b * bar, dur: .25, f: 55, amp: .22, type: 'kick' }); notes.push({ t: b * bar + beat * 2.5, dur: .25, f: 55, amp: .16, type: 'kick' }); }
    } else if (b % 2 === 0) notes.push({ t: b * bar, dur: bar * 2, f: midi(root + ch[0] + 24), amp: .035, type: 'bell' });
  }
  const noise = rng(seed * 7 + 1);
  for (const n of notes) {
    const s0 = Math.floor(n.t * SR), s1 = Math.min(total, Math.floor((n.t + n.dur) * SR));
    const pan = n.type === 'pluck' ? .35 + r() * .3 : .5, det = 1 + (r() - .5) * .004;
    for (let i = s0; i < s1; i++) {
      const tt = (i - s0) / SR, p = tt / n.dur;
      let v = 0, env;
      if (n.type === 'pad') { env = Math.min(1, tt / .8) * (p > .8 ? (1 - p) / .2 : 1); const w = 2 * Math.PI * n.f * tt; v = (Math.sin(w * det) + .5 * Math.sin(w * 2 * det) * (.5 + .5 * Math.sin(tt * .7)) + Math.sin(w / det)) / 2.5 * env; }
      else if (n.type === 'bass') { env = Math.min(1, tt / .03) * (p > .7 ? (1 - p) / .3 : 1); const w = 2 * Math.PI * n.f * tt; v = (Math.sin(w) + .3 * Math.sin(w * 2)) * env; }
      else if (n.type === 'pluck') { env = Math.exp(-tt * 4.5) * Math.min(1, tt / .005); const w = 2 * Math.PI * n.f * tt; v = (Math.sin(w) + .4 * Math.sin(w * 2) * Math.exp(-tt * 8) + .15 * Math.sin(w * 3) * Math.exp(-tt * 12)) * env; }
      else if (n.type === 'hat') { env = Math.exp(-tt * 90); v = (noise() * 2 - 1) * env; }
      else if (n.type === 'snare') { env = Math.exp(-tt * 28); v = ((noise() * 2 - 1) * .7 + .3 * Math.sin(2 * Math.PI * 180 * tt)) * env; }
      else if (n.type === 'bell') { env = Math.exp(-tt * 1.6) * Math.min(1, tt / .01); const w = 2 * Math.PI * n.f * tt; v = (Math.sin(w) + .5 * Math.sin(w * 2.76) * Math.exp(-tt * 3) + .25 * Math.sin(w * 5.4) * Math.exp(-tt * 5)) * env; }
      else if (n.type === 'kick') { env = Math.exp(-tt * 14); v = Math.sin(2 * Math.PI * (n.f + 60 * Math.exp(-tt * 30)) * tt) * env; }
      L[i] += v * n.amp * (1 - pan) * 2; R[i] += v * n.amp * pan * 2;
    }
  }
  /* tek kutuplu alçak geçiren (lo-fi sıcaklık) + yumuşak sınırlayıcı + baş/son yumuşatma */
  const a = style === 'hareketli' ? .55 : style === 'spa' ? .25 : .35;
  for (let i = 0; i < total; i++) {
    lpL += a * (L[i] - lpL); lpR += a * (R[i] - lpR);
    let fade = Math.min(1, i / SR, (total - i) / SR);
    L[i] = Math.tanh(lpL * 1.2) * fade; R[i] = Math.tanh(lpR * 1.2) * fade;
  }
  return { L, R, bpm };
}

function wav(file, L, R) {
  const n = L.length, buf = Buffer.alloc(44 + n * 4);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 4, 4); buf.write('WAVE', 8); buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22); buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(n * 4, 40);
  for (let i = 0; i < n; i++) { buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, L[i])) * 32767), 44 + i * 4); buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, R[i])) * 32767), 46 + i * 4); }
  fs.writeFileSync(file, buf);
}

fs.mkdirSync(OUT, { recursive: true });
const STYLES = STYLE === 'karisik' ? ['lofi', 'hareketli', 'spa'] : [STYLE];
for (let k = 1; k <= N; k++) {
  const st = STYLES[(k - 1) % STYLES.length];
  const { L, R, bpm } = render(1000 + k * 37, st);
  const f = path.join(OUT, st + '-' + String(k).padStart(2, '0') + '.wav');
  wav(f, L, R);
  console.log(f + ' | ' + bpm + ' bpm | ' + SEC + ' sn');
}
