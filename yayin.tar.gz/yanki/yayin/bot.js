/* Yayın oyuncusu: oyunun step() içindeki /*HOOK*‌/ noktasına enjekte edilir.
   Her karede: sarı noktaya yönelir, yankıların 30 kare sonrasını tahmin edip kaçar, engellere çarpmadan yol seçer.
   Mükemmel değil; arada ölür. Yayın için bu iyidir: ölüm = drama, tekrar = yeni tur. */
(function(){
  if(typeof window.__state==='undefined'){window.__state=1;window.__best=0;window.__games=0;}
  if(score>window.__best)window.__best=score;
  var b=B(),best=null,bd=1e9,k,i,f,d;
  for(k=0;k<tg.length;k++){var t=tg[k];if(!t.on)continue;d=dist(px,py,t.x,t.y);if(d<bd){bd=d;best=t}}
  var fx=0,fy=0;
  if(best){var tx=(best.x-px)*W,ty=(best.y-py)*H;d=Math.max(1,Math.sqrt(tx*tx+ty*ty));fx+=tx/d;fy+=ty/d;}
  var danger=U*PR*4.5;
  for(i=0;i<ghosts.length;i++){
    for(f=0;f<=30;f+=5){
      var p=ghostPos(ghosts[i],frame+f),gx=(px-p.x)*W,gy=(py-p.y)*H,gd=Math.max(1,Math.sqrt(gx*gx+gy*gy));
      if(gd<danger){var w=(1-gd/danger)*(1-f/40)*3.2;fx+=gx/gd*w;fy+=gy/gd*w;}
    }
  }
  var m=U*.07;
  if((px-b.x0)*W<m)fx+=1.2;if((b.x1-px)*W<m)fx-=1.2;if((py-b.y0)*H<m)fy+=1.2;if((b.y1-py)*H<m)fy-=1.2;
  var n=Math.sqrt(fx*fx+fy*fy)||1,sp=U*.0125,ang=Math.atan2(fy/n,fx/n),ndx=0,ndy=0;
  var tries=[0,.5,-.5,1,-1,1.6,-1.6,2.2,-2.2,2.8,-2.8,3.14];
  for(var q=0;q<tries.length;q++){
    var a=ang+tries[q],cx=Math.cos(a)*sp,cy=Math.sin(a)*sp,bad=false;
    if(OB.length){
      var ox=px,oy=py;
      for(var s=3;s<=12&&!bad;s+=3){px=ox+cx*s/W;py=oy+cy*s/H;if(obHit(lt0+frame+s))bad=true;}
      px=ox;py=oy;
    }
    if(!bad){ndx=cx/W;ndy=cy/H;break;}
  }
  move(ndx,ndy);
})();
